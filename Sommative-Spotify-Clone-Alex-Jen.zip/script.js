const supabaseUrl = "https://urncjnxtdtshgbjgfhiz.supabase.co";
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVybmNqbnh0ZHRzaGdiamdmaGl6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzQ1MzYxODQsImV4cCI6MjA1MDExMjE4NH0.PSJAjjx4M-qCtUZ6bRqBr1PtX3qAKmuau_HfI5gUiYU";

const username = document.getElementById("username");
const password = document.getElementById("password");
const btn = document.querySelector("button");

// Create the Supabase client
const supabaseClient = supabase.createClient(supabaseUrl, supabaseKey);

const trouverUtilisateur = async () => {
  const { data, error } = await supabaseClient
    .from('Utilisateurs') 
    .select('*') 
    .eq('username', username.value) 
    .eq('password', password.value); 

  if (error) {
    console.error('Erreur', error.message);
    return;
  }

  if (data.length > 0) {
    // Mettre a la page de musique
    window.location = "Musique/musique.html";
  } else {
    console.log('Invalid username or password');
    window.alert("L'utilisateur ou le mot de passe est incorrect");
  }
};

btn.addEventListener("click", () => {
  if (username.value !== "" && password.value !== "") {
    trouverUtilisateur();
  } else {
    window.alert("Ne laissez pas les champs vides!");
  }
});