const supabaseUrl = "https://urncjnxtdtshgbjgfhiz.supabase.co";
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVybmNqbnh0ZHRzaGdiamdmaGl6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzQ1MzYxODQsImV4cCI6MjA1MDExMjE4NH0.PSJAjjx4M-qCtUZ6bRqBr1PtX3qAKmuau_HfI5gUiYU";

const username = document.getElementById("username");
const password = document.getElementById("password");
const btn = document.querySelector("button");

// Création du client Supabase pour interagir avec la base de données
const supabaseClient = supabase.createClient(supabaseUrl, supabaseKey);

const createAccount = async () => {
  // Vérifier si le `username` existe déjà
  const { data: existingUser, error: fetchError } = await supabaseClient
    .from('Utilisateurs') // Remplacez par le nom correct de votre table
    .select('username')
    .eq('username', username.value);

  if (fetchError) {
    console.error('Erreur lors de la vérification du nom d’utilisateur:', fetchError.message);
    window.alert("Une erreur est survenue. Veuillez réessayer.");
    return false;
  }

  if (existingUser.length > 0) {
    // Si un utilisateur avec le même nom d'utilisateur existe déjà
    window.alert("Ce nom d'utilisateur est déjà pris. Veuillez en choisir un autre.");
    return false;
  }

  // Si le `username` est disponible, insérez le nouvel utilisateur
  const { data, error } = await supabaseClient
    .from('Utilisateurs') // Changez par le nom de votre table
    .insert([
      {
        username: username.value,
        password: password.value,
      },
    ]);

  if (error) {
    console.error('Erreur lors de la création du compte:', error.message);
    window.alert("Une erreur est survenue lors de la création du compte.");
    return false;
  }

  console.log('Compte créé avec succès:', data);
  return true;
};

btn.addEventListener("click", () => {
  if (username.value !== "" && password.value !== "") {
    createAccount().then((success) => {
      if (success) {
        // Redirection vers une autre page après succès
        window.location = "/index.html";
      }
    });
  } else {
    window.alert("Ne laissez pas les champs vides !");
  }
});
