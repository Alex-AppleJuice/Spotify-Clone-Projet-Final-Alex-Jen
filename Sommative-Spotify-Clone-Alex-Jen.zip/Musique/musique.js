const containerAlbum = document.getElementById("containter-albums");
const containerArtiste = document.getElementById("contanier-artiste")

localStorage.setItem("Index", 0);
setStorage = (ind) => {
  localStorage.setItem("Index", ind);
}

const nomAlbum = ["Country", "Pop", "Roadtrip", "80s" ];
const AlbumImg = ["../Images/country.jpg", "../Images/pop.jpg", "../Images/roadtrip.jpg", "../Images/80s.jpg" ];
const chasonCompte = [8, 7, 9, 8 ];

class monAlbum {
  constructor(titre, nombreChason, image) {
    this.titre = titre;
    this.nombreChason = nombreChason;
    this.image = image;
  }
}

const albums = [];
for(let i = 0; i < nomAlbum.length; i++){
  albums.push(new monAlbum(nomAlbum[i], chasonCompte[i], AlbumImg[i]));
}

const nomArtist = ["Zach Bryan", "Taylor Swift", "Ariana Grande", "One direction" ];
const ArtistImg = ["../Images/zach_bryan.jpg", "../Images/taylor_swift.jpg", "../Images/ariana.jpg", "../Images/one_direction.jpg" ];
const chasonNombre = [9, 10, 7, 9 ];

class monArtiste {
  constructor(titre, nombreChason, image) {
    this.titre = titre;
    this.nombreChason = nombreChason;
    this.image = image;
  }
}

const artiste = [];
for(let i = 0; i < nomArtist.length; i++){
  artiste.push(new monArtiste(nomArtist[i], chasonNombre[i], ArtistImg[i]));
}

function creeRanger(liste, container){
  let storagenum = 0;
  liste.forEach(ch => {
    const aHref = document.createElement('a');
    aHref.href = "../Playlist/playlist.html";
    aHref.setAttribute("onClick", "setStorage("+storagenum.toString()+")")
    storagenum ++;

    // Créer la nouvelle div
    const chDiv = document.createElement('div');
    chDiv.classList.add('playlist');

    // Créer l'élément image pour l'album
    const chImage = document.createElement('img');
    chImage.src = ch.image;

    // Créer le h2 piur le titre de l'album
    const chTitle = document.createElement('h2');
    chTitle.textContent = ch.titre;

    // Créer le h4 piur le montant de chansons
    const chCompte = document.createElement('h4');
    chCompte.textContent = `${ch.nombreChason} chanson`;

    // Append l'élément a albumDiv
    chDiv.appendChild(chImage);
    chDiv.appendChild(chTitle);
    chDiv.appendChild(chCompte);

    aHref.appendChild(chDiv);
    // Append le albumDiv au albumContainer
    container.appendChild(aHref);
  });
}

creeRanger(albums, containerAlbum);
creeRanger(artiste, containerArtiste);
