localStorage.setItem("chanson", 0)
function setChanson(chason) {
  localStorage.setItem("chanson", chason)
}

const contianerPlaylist = document.getElementById("container-playlist");

class Chanson{
  constructor(nom, artiste, durre, img){
    this.nom = nom;
    this.artiste = artiste;
    this.durre = durre;
    this.img = img;
  }
}
class Titre{
  constructor(nom, image, Nombreschasons, titre){
    this.nom = nom;
    this.image = image;
    this.Nombreschasons = Nombreschasons;
    this.titre = titre;
  }
}

let titres = [new Titre("Arianas", "../Images/ariana.jpg", "4", "Arianas best hits")]
let chansons = [[new Chanson("Side by sider", "Ariana grande", "3:20", "../Images/ariana.jpg"), new Chanson("God's plan", "Drake", "3:58", "../Images/ariana.jpg")]];

document.getElementById("Titre").innerHTML = titres[localStorage.getItem("Index")].titre;

document.getElementById("nombre-chans").innerHTML = titres[localStorage.getItem("Index")].Nombreschasons + " chasons";

document.getElementById("cover").src = titres[localStorage.getItem("Index")].image;
console.log(localStorage.getItem("chanson"));


const currentIndex = chansons[localStorage.getItem("Index")]; // Retrieve chansons for the current Titre
// Retrieve and display the current chansons
const currentChansons = chansons[currentIndex];
if (currentChansons) {
  currentChansons.forEach((chanson, chansonIndex) => {
    let chansonElement = document.createElement("div");
    chansonElement.classList.add("chanson");
    chansonElement.innerHTML = `
      <img src="${chanson.img}" alt="${chanson.nom}">
      <h3>${chanson.nom}</h3>
      <h4>${chanson.artiste}</h4>
      <p>${chanson.duree}</p>
    `;

    // Add click event to set the current chanson index
    chansonElement.addEventListener("click", () => setChanson(chansonIndex));

    containerPlaylist.appendChild(chansonElement);
  });
} else {
  console.error("No chansons found for the current index.");
}